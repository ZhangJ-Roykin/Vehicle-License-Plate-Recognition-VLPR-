alpha = set()
with open("/home/wangxiang/VLPR/data/train-data-label.txt", 'r', encoding='utf-8') as fh:
    for line in fh:
        line = line.strip('\n')
        line = line.rstrip()
        words = line.split()
        for cur_ in words[0][:-1]:
            alpha.update(cur_)
        pass


alphabet = []
with open("alphabet.txt", 'w', encoding='utf-8') as f:
    for cur_ in alpha:
        alphabet.append(cur_)

    alphabet.sort()
    for cur_ in alphabet:
        f.write(cur_)
